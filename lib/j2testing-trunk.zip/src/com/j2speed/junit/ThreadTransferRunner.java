/**
 * Copyright � 2011 J2Speed. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
package com.j2speed.junit;

import static java.awt.EventQueue.invokeLater;

import java.lang.Thread.UncaughtExceptionHandler;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.CountDownLatch;

import org.junit.runner.Runner;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.junit.runners.model.Statement;

/**
 * A {@link Runner} for unit tests that use multiple threads to run.
 * <p>
 * This runner allows to capture exceptions and assertion from any thread that the test will use.
 * </p>
 * <p>
 * To achieve that, the runner will replace the default UncaughtExceptionHandler with a custom one that capture uncaught
 * exceptions on all threads, notifying JUnit when the test method is complete.
 * </p>
 * <p>
 * A test class or test method can be annotated with @{@link StartOnEDT} to tell the runner to start each or the
 * specific method, respectively, on the Swing Event Dispatch Thread. This could be useful when testing UI related
 * objects.
 * </p>
 * <p>
 * Naturally, this runner cannot be used in all situations. In fact, if you have a SecurityManger installed, you need to
 * make sure that your thread runs with the right permissions to be able to set the default UncaughtExceptionHandler.<br>
 * Also, if any of the threads involved in the test uses specific UncaughtExceptionHandlers, they will take over the
 * default, making this runner deaf to the exceptions they would throw.
 * </p>
 * <p>
 * Even with the above limitations, the runner maintains its general convenience, considering that the cases that would
 * limit its use are rare.
 * </p>
 * <p>
 * See the unit test source for the runner itself for a good source of use example.
 * </p>
 * 
 * @author alienisty
 */
public class ThreadTransferRunner extends BlockJUnit4ClassRunner {

  /**
   * Specifies whether the test should start on the EDT
   */
  @Retention(RetentionPolicy.RUNTIME)
  @Target({ ElementType.TYPE, ElementType.METHOD })
  public static @interface StartOnEDT {}

  public ThreadTransferRunner(Class<?> klass) throws InitializationError {
    super(klass);
  }

  @Override
  protected Statement methodInvoker(FrameworkMethod method, Object test) {
    Statement statement = super.methodInvoker(method, test);
    if (shouldStartOnEDT(method)) {
      statement = new EDTUncaughtExceptionStatement(statement);
    }
    else {
      statement = new UncaughtExceptionStatement(statement);
    }
    return statement;
  }

  private static boolean shouldStartOnEDT(FrameworkMethod method) {
    return method.getAnnotation(StartOnEDT.class) != null || method.getMethod().getDeclaringClass().getAnnotation(StartOnEDT.class) != null;
  }

  /**
   * A {@link Statement} that catches exceptions from multiple threads.
   */
  private static class UncaughtExceptionStatement extends Statement implements UncaughtExceptionHandler {

    final Statement delegate;

    private volatile Throwable throwable;

    private UncaughtExceptionStatement(Statement delegate) {
      this.delegate = delegate;
    }

    @Override
    public final void evaluate() throws Throwable {
      UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
      Thread.setDefaultUncaughtExceptionHandler(this);
      try {
        doEvaluate();
        Throwable th = throwable;
        if (th != null) {
          throw th;
        }
      }
      catch (InvocationTargetException e) {
        throw e.getTargetException();
      }
      finally {
        Thread.setDefaultUncaughtExceptionHandler(previous);
      }
    }

    @Override
    public final void uncaughtException(Thread t, Throwable e) {
      throwable = e;
      done();
    }

    void doEvaluate() throws Throwable {
      delegate.evaluate();
    }

    void done() {}
  }

  /**
   * A {@link Statement} that catches exceptions from multiple threads and runs in the EDT.
   */
  private static class EDTUncaughtExceptionStatement extends UncaughtExceptionStatement {

    private final CountDownLatch done = new CountDownLatch(1);

    private EDTUncaughtExceptionStatement(Statement delegate) {
      super(delegate);
    }

    @Override
    void doEvaluate() throws Throwable {
      invokeLater(new Runnable() {
        @Override
        public void run() {
          try {
            delegate.evaluate();
            done.countDown();
          }
          catch (Throwable e) {
            EDTUncaughtExceptionStatement.this.uncaughtException(Thread.currentThread(), e);
          }
        }
      });
      done.await();
    }

    @Override
    void done() {
      done.countDown();
    }
  }
}
