/**
 * Copyright � 2011 J2Speed. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
package com.j2speed.junit;

import static java.awt.EventQueue.invokeAndWait;
import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static junit.framework.Assert.fail;

import java.awt.EventQueue;
import java.io.FileNotFoundException;

import org.junit.Test;
import org.junit.runner.RunWith;

import com.j2speed.junit.ThreadTransferRunner.StartOnEDT;

/**
 * Unit test for the {@link ThreadTransferRunner}.
 * <p>
 * This is a good source of examples on how to use the runner, in fact, it itself uses the runner to execute the tests.
 * </p>
 * 
 * @author Alex
 */
@SuppressWarnings("all")
@RunWith(ThreadTransferRunner.class)
public class ThreadTransferRunnerTest {

  @Test
  @StartOnEDT
  public void testIsOnEDT() throws Exception {
    // We are on the EDT here
    assertTrue(EventQueue.isDispatchThread());
  }

  @Test
  public void testIsNotOnEDT() throws Exception {
    // This is not the EDT (Well, unless JUnit has been started on the EDT, but that would be simply wrong!)
    assertFalse(EventQueue.isDispatchThread());
  }

  @Test(expected = AssertionError.class)
  @StartOnEDT
  public void testAssertionFromASpawnedThread() throws InterruptedException {
    // This test would normally pass without using the runner. In fact, exceptions thrown on threads that are not the
    // one that JUnit is using to run the tests, would not be noticed.
    // I'm in the EDT
    Thread th = new Thread() {
      @Override
      public void run() {
        // I'm not in the EDT
        fail("Expected to fail");
      }
    };
    th.start();
    th.join(1000);
  }

  @Test(expected = FileNotFoundException.class)
  @StartOnEDT
  public void testExceptionFromEDT() throws FileNotFoundException {
    throw new FileNotFoundException();
  }

  @Test(expected = NullPointerException.class)
  @StartOnEDT
  public void testRuntimeExceptionFromEDT() {
    throw new NullPointerException();
  }

  @Test(expected = NullPointerException.class)
  @StartOnEDT
  public void testRuntimeExceptionFromASpawnedThreadFromEDT() throws InterruptedException {
    // I'm in the EDT
    Thread th = new Thread() {

      @Override
      public void run() {
        // I'm not in the EDT
        throw new NullPointerException();
      }
    };
    th.start();
    th.join(1000);
  }

  @Test(expected = NullPointerException.class)
  public void testRuntimeExceptionFromASpawnedThread() throws InterruptedException {
    // I'm not in the EDT
    Thread th = new Thread() {
      @Override
      public void run() {
        // I'm not in the EDT
        throw new NullPointerException();
      }
    };
    th.start();
    th.join(1000);
  }

  @Test(expected = AssertionError.class)
  public void testAssertionErrorFromInvokeAndWait() throws Exception {
    // I'm not in the EDT
    invokeAndWait(new Runnable() {
      @Override
      public void run() {
        // I'm in the EDT
        assertTrue(false);
      }
    });
  }
}
